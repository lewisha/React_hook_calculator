# React Calculator With React Hooks Old Version
 Simple but well styled Calculator made by using hooks(no more class components!)
https://vasilykhromykh.github.io/React-Calculator-With-React-Hooks/
![image](https://user-images.githubusercontent.com/71073510/192042596-299b86ee-18c2-462f-9674-d7c0b3839b35.png)

